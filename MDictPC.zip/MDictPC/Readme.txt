Please read the install.txt for install procedures.

Author:
Rayman Zhang
raymanzhang@gmail.com
http://www.octopus-studio.com